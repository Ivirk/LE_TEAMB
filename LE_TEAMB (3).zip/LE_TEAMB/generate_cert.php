<?php
session_start();
include 'shjpdb.php';

require __DIR__ . '/vendor/autoload.php';
use Dompdf\Dompdf;

if (!isset($_SESSION['username'])) header("Location: user_loginpage.php");
if (!isset($_GET['request_id'])) die("Error: No certificate request found.");

$request_id = (int)$_GET['request_id'];
$user_id = $_SESSION['parishioner_id'];

// Get certificate request
$stmt = $conn->prepare("SELECT * FROM CertificateRequests WHERE request_id=? AND parishioner_id=? AND status='Approved'");
$stmt->bind_param("ii", $request_id, $user_id);
$stmt->execute();
$cert = $stmt->get_result()->fetch_assoc();
if (!$cert) die("Error: Certificate not found or not approved.");

// Get record from Baptismal or Confirmation table
function getRecord($conn, $table, $name) {
    foreach (["full_name = ?", "UPPER(full_name) = UPPER(?)"] as $clause) {
        $stmt = $conn->prepare("SELECT * FROM $table WHERE $clause");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        if ($r = $stmt->get_result()->fetch_assoc()) return $r;
    }
    return [];
}

$record = $cert['type'] === 'Baptismal' 
    ? getRecord($conn, 'BaptismalRecords', $cert['owner_name']) 
    : getRecord($conn, 'ConfirmationRecords', $cert['owner_name']);
if (!$record) die("Error: No {$cert['type']} record found.");


// Set up details
$type = ucfirst($cert['type']);
$name = htmlspecialchars($cert['owner_name']);
$today = date("F j, Y");
$father = htmlspecialchars($record['father_name'] ?? $cert['father_name'] ?? 'Not specified');
$mother = htmlspecialchars($record['mother_name'] ?? $cert['mother_name'] ?? 'Not specified');
$purpose = htmlspecialchars($cert['reason']);

if ($cert['type'] === 'Baptismal') {
    $date = !empty($record['date_baptism']) ? date("F j, Y", strtotime($record['date_baptism'])) : 'Date on file';
    $place = htmlspecialchars($record['place_baptism'] ?? 'Sacred Heart of Jesus Parish');
    $officiant = htmlspecialchars($record['priest_name'] ?? 'Parish Priest');
    $godfather = htmlspecialchars($record['godfather'] ?? 'Not specified');
    $godmother = htmlspecialchars($record['godmother'] ?? 'Not specified');
    $sponsorRow = "
        <div class='detail-row'><span class='label'>Godfather:</span><span class='value'>$godfather</span></div>
        <div class='detail-row'><span class='label'>Godmother:</span><span class='value'>$godmother</span></div>";
} else {
    $date = !empty($record['date_confirmation']) ? date("F j, Y", strtotime($record['date_confirmation'])) : 'Date on file';
    $place = htmlspecialchars($record['place_confirmation'] ?? 'Sacred Heart of Jesus Parish');
    $officiant = htmlspecialchars($record['priest_name'] ?? 'Parish Priest');
    $sponsors = htmlspecialchars($record['sponsors'] ?? 'Not specified');
    $sponsorRow = "
        <div class='detail-row'><span class='label'>Sponsors:</span><span class='value'>$sponsors</span></div>";
}

$certText = "This is to certify that <strong>$name</strong> was " . 
    strtolower($type) . " in this Parish on $date according to the rites of the Roman Catholic Church.";

$html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <title>Certificate of $type</title>
    <style>
        body {
            font-family: "Times New Roman", serif;
            background: white;
            margin: 0;
            padding: 0;
        }

        .certificate {
            width: 150mm;
            height: 205mm;
            margin: auto;
            padding: 25mm 20mm;
            background: #fff;
            border: 6px solid #d4af37;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .header {
            text-align: center;
            margin-bottom: 10mm;
        }

        .parish-name {
            font-size: 20pt;
            color: #8b6914;
            font-weight: bold;
            text-transform: uppercase;
        }

        .parish-address {
            font-size: 10pt;
            color: #666;
            margin-top: 4pt;
        }

        .cert-title {
            font-size: 24pt;
            color: #8b6914;
            margin: 12pt 0;
            text-transform: uppercase;
            font-weight: bold;
            text-align: center;
        }

        .recipient {
            font-size: 18pt;
            color: #8b6914;
            margin: 8pt 0;
            font-weight: bold;
            text-transform: uppercase;
            text-align: center;
        }

        .cert-text {
            font-size: 12pt;
            margin: 10pt auto;
            line-height: 1.6;
            color: #333;
            text-align: center;
            width: 80%;
        }

        .details {
            margin: 10mm auto;
            font-size: 11pt;
            background: #fafafa;
            padding: 6mm 8mm;
            border-radius: 3px;
            border-left: 4px solid #d4af37;
            width: 85%;
            box-sizing: border-box;
        }

        .detail-row {
            margin: 3mm 0;
            display: flex;
            justify-content: flex-start;
        }

        .label {
            font-weight: bold;
            color: #8b6914;
            width: 45mm;
            flex-shrink: 0;
        }

        .value {
            flex: 1;
            color: #333;
        }

        .given-text {
            margin: 8mm 0;
            font-style: italic;
            color: #666;
            font-size: 10pt;
            text-align: center;
        }

        .footer {
            margin-top: 10mm;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            font-size: 11pt;
        }

        .signature-section {
            text-align: center;
        }

        .signature-line {
            border-bottom: 1px solid #333;
            width: 60mm;
            height: 10mm;
            margin: 0 auto 3mm;
        }

        .cert-number {
            text-align: center;
            margin-top: 8mm;
            font-size: 9pt;
            color: #999;
            border-top: 1px solid #eee;
            padding-top: 3mm;
        }
    </style>
</head>
<body>
    <div class="certificate">
        <div class="header">
            <div class="parish-name">Sacred Heart of Jesus Parish</div>
            <div class="parish-address">Barrio Obrero, Davao City | Tel: (082) 227-0397</div>
        </div>

        <div class="cert-title">Certificate of $type</div>
        <div class="recipient">$name</div>
        <div class="cert-text">$certText</div>

        <div class="details">
            <div class="detail-row">
                <span class="label">Father:</span>
                <span class="value">$father</span>
            </div>
            <div class="detail-row">
                <span class="label">Mother:</span>
                <span class="value">$mother</span>
            </div>
            $sponsorRow
            <div class="detail-row">
                <span class="label">Date of $type:</span>
                <span class="value">$date</span>
            </div>
            <div class="detail-row">
                <span class="label">Place:</span>
                <span class="value">$place</span>
            </div>
            <div class="detail-row">
                <span class="label">Officiant:</span>
                <span class="value">$officiant</span>
            </div>
            <div class="detail-row">
                <span class="label">Purpose:</span>
                <span class="value">$purpose</span>
            </div>
        </div>

        <div class="given-text">
            Given this $today at Sacred Heart of Jesus Parish, Davao City
        </div>

        <div class="footer">
            <div>
                <strong>Date Issued:</strong><br>$today
            </div>
            <div class="signature-section">
                <div class="signature-line"></div>
                <strong>Msgr. Paul A. Cuison</strong><br>Parish Priest
            </div>
        </div>
    </div>
</body>
</html>
HTML;

// ✅ Generate PDF using Dompdf
if (isset($_GET['download'])) {
    require 'vendor/autoload.php';

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $filename = "Certificate_{$cert['type']}_" . preg_replace('/\W+/', '_', $cert['owner_name']) . "_" . date('Y-m-d') . ".pdf";
    $dompdf->stream($filename, ["Attachment" => true]);
    exit;
}

// ✅ Preview Mode
echo "<div style='text-align:center; padding:20px; background:#f5f5f5;'>
        <h2>Certificate Preview</h2>
        <p style='color:#666;'>Review before downloading</p>
        <a href='?request_id=$request_id&download=1' 
           style='background:#d4af37; color:white; padding:12px 25px; text-decoration:none; border-radius:5px; font-weight:bold; box-shadow:0 2px 5px rgba(0,0,0,0.2);'>
           📄 Download Certificate as PDF
        </a>
      </div>";
echo $html;
?>
